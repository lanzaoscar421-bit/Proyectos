public enum Genero {

    SHONEN, SHEINEN, ISEKAI, SHOJO, HORROR,


}
